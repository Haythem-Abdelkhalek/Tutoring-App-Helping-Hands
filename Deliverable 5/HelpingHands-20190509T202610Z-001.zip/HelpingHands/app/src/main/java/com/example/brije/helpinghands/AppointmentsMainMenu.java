package com.example.brije.helpinghands;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.brije.helpinghands.Login;
import com.example.brije.helpinghands.MainActivity;
import com.example.brije.helpinghands.R;

public class AppointmentsMainMenu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointments_main_menu);

        final Button Login =(Button) findViewById(R.id.btnBooked);

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AppointmentsMainMenu.this, ClassSchedule.class));
            }
        });
    }
}
