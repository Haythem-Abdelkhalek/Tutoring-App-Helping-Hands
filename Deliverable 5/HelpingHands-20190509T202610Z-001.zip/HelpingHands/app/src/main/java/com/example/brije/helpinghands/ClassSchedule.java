package com.example.brije.helpinghands;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ClassSchedule extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_class_schedule);

        Button IS451 = (Button) findViewById(R.id.btnclass1);
        Button IS448 = (Button) findViewById(R.id.btnclass2);
        Button IS436 = (Button) findViewById(R.id.btnclass3);

        IS451.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ClassSchedule.this, BookSession.class));
            }
        });

        IS448.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ClassSchedule.this, BookSession.class));
            }
        });

        IS436.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ClassSchedule.this, BookSession.class));
            }
        });
    }
}
