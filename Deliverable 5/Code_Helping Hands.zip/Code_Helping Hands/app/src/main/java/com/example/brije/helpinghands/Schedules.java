package com.example.brije.helpinghands;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Schedules extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedules);


    }
}
