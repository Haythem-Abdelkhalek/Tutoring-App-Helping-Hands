package com.example.brije.helpinghands;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.LoginFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button Login = (Button) findViewById(R.id.btnLogin2);
        Button Supervisor = (Button) findViewById(R.id.btnSupervisor);
        final EditText txtEmailHint = (EditText) findViewById(R.id.txtEmail);
        final EditText txtPasswordHint = (EditText) findViewById(R.id.txtPassword);

        final Bundle bundle = new Bundle();
        final Bundle bundle2 = new Bundle();


        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String Email = txtEmailHint.getText().toString();
                String password = txtPasswordHint.getText().toString();

                bundle.putString("Email", Email);
                bundle2.putString("password", password);

                Intent intent = new Intent(Login.this, AppointmentsMainMenu.class);
                startActivity(intent);
            }
        });

        Supervisor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Email = txtEmailHint.getText().toString();
                String password = txtPasswordHint.getText().toString();

                bundle.putString("Email", Email);
                bundle2.putString("password", password);

                Intent intent = new Intent(Login.this, Schedules.class);
                startActivity(intent);

            }
        });
    }
}
