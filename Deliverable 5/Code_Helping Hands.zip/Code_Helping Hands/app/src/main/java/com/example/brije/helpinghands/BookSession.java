package com.example.brije.helpinghands;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BookSession extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_session);

        Button time1 = (Button) findViewById(R.id.btntime1);
        Button time2 = (Button) findViewById(R.id.btntime2);
        Button time3 = (Button) findViewById(R.id.btntime3);
        Button time4 = (Button) findViewById(R.id.btntime4);
        Button time5 = (Button) findViewById(R.id.btntime5);
        Button time6 = (Button) findViewById(R.id.btntime6);
        Button time7 = (Button) findViewById(R.id.btntime7);
        Button time8 = (Button) findViewById(R.id.btntime8);
        Button time9 = (Button) findViewById(R.id.btntime9);

        time1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookSession.this, Confirmation.class);
                startActivity(intent);
            }
        });

        time2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookSession.this, Confirmation.class);
                startActivity(intent);
            }
        });


        time3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookSession.this, Confirmation.class);
                startActivity(intent);
            }
        });


        time4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookSession.this, Confirmation.class);
                startActivity(intent);
            }
        });

        time5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookSession.this, Confirmation.class);
                startActivity(intent);
            }
        });


        time6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookSession.this, Confirmation.class);
                startActivity(intent);
            }
        });

        time7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookSession.this, Confirmation.class);
                startActivity(intent);
            }
        });

        time8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookSession.this, Confirmation.class);
                startActivity(intent);
            }
        });

        time9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookSession.this, Confirmation.class);
                startActivity(intent);
            }
        });

    }
}
